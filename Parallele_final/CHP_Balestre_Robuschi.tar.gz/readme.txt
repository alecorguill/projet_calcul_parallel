Commandes pour compiler et utiliser le code 

>> make
>> mpirun -n 1 ./run 

ou 1 correspond au nombre de processeur dont l'utilisation est souhaitée. 
